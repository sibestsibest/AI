using Ai.Phase10.Demos;

// ======================================================================
// MINI AI — PHASE 10: MEMORY
//
//     ShortTermMemory   cửa sổ những gì vừa xảy ra (có giới hạn cứng)
//     LongTermMemory    kho bền, phai dần theo giá trị
//     Fact              nội dung + siêu dữ liệu quyết định số phận nó
//     MemoryStore       Store / Retrieve / Search / Rank / Forget
//
// Nguyên tắc xuyên suốt: KHÔNG lưu mọi thứ một cách mù quáng.
// ======================================================================

Console.WriteLine("############################################");
Console.WriteLine("#   MINI AI — PHASE 10: MEMORY             #");
Console.WriteLine("############################################\n");

MemoryDemo.Run();

Console.WriteLine("\n\n=== PHASE 10 HOÀN TẤT ===");
