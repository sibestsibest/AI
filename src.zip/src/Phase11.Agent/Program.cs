using Ai.Phase11.Demos;

// ======================================================================
// MINI AI — PHASE 11: AI AGENT
//
// Ghép tất cả lại:
//     Language Model  -> bộ phân loại ý định (mạng neural, Phase 2–6)
//     Memory          -> Phase 10
//     Reasoning       -> Phase 9
//     Tools           -> Calculator, Search, Database
//
// Không dùng API AI nào. Mọi thành phần đều tự viết từ Phase 1.
// ======================================================================

Console.WriteLine("############################################");
Console.WriteLine("#   MINI AI — PHASE 11: AI AGENT           #");
Console.WriteLine("############################################\n");

AgentDemo.Run();

Console.WriteLine("\n\n=== PHASE 11 HOÀN TẤT — TOÀN BỘ LỘ TRÌNH ĐÃ XONG ===");
